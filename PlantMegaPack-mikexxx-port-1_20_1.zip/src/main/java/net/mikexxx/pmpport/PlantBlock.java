package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Generic staged plant: normal block + JSON cross model (cutout via model json), so shaders treat it like any
 * other plant block. STAGE grows by random ticks or bone meal, honeycomb (WAXED) freezes the stage.
 */
public class PlantBlock extends BushBlock implements BonemealableBlock {
    public enum Type { GROUND, HANGING, FLOATING }

    public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 9);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 14, 14);
    private static final VoxelShape FLAT_SHAPE = Block.box(0, 0, 0, 16, 1.5, 16);
    private static final VoxelShape HANG_SHAPE = Block.box(2, 2, 2, 14, 16, 14);

    final int maxStage;
    final Type type;
    String harvest;
    boolean flat;

    /** flat plants (ground covers, lily pads) lie on the ground like carpets/petals */
    public PlantBlock flat() {
        this.flat = true;
        return this;
    }

    public PlantBlock withHarvest(String item) {
        this.harvest = item;
        return this;
    }

    public PlantBlock(Properties props, int maxStage, Type type) {
        super(props);
        this.maxStage = Math.max(0, Math.min(9, maxStage));
        this.type = type;
        this.registerDefaultState(this.stateDefinition.any().setValue(STAGE, 0).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(STAGE, WAXED);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        if (flat) return FLAT_SHAPE;
        return type == Type.HANGING ? HANG_SHAPE : SHAPE;
    }

    // ----- placement -----
    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (type == Type.FLOATING) {
            return level.getFluidState(pos).getType() == Fluids.WATER;
        }
        return state.isFaceSturdy(level, pos, Direction.UP) || state.is(net.minecraft.tags.BlockTags.DIRT)
                || state.getBlock() instanceof PlanterBlock || state.getBlock() instanceof ShapedBlock;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        if (type == Type.HANGING) return Block.canSupportCenter(level, pos.above(), Direction.DOWN);
        if (type == Type.FLOATING) {
            return level.getFluidState(pos.below()).getType() == Fluids.WATER && level.getFluidState(pos).isEmpty();
        }
        return super.canSurvive(state, level, pos);
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        if (!s.canSurvive(l, p)) return Blocks.AIR.defaultBlockState();
        return s;
    }

    // ----- growth -----
    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(WAXED)) return;
        int st = state.getValue(STAGE);
        if (st < maxStage && random.nextInt(6) == 0 && level.getRawBrightness(pos, 0) >= 8) {
            level.setBlock(pos, state.setValue(STAGE, st + 1), 2);
        }
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return !state.getValue(WAXED) && state.getValue(STAGE) < maxStage;
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource r, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource r, BlockPos pos, BlockState state) {
        int st = state.getValue(STAGE);
        if (st < maxStage) level.setBlock(pos, state.setValue(STAGE, st + 1), 2);
    }

    // ----- wax -----
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.HONEYCOMB) && !state.getValue(WAXED)) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(WAXED, true), 3);
                level.levelEvent(null, 3003, pos, 0); // wax on particles + sound
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && state.getValue(WAXED)) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(WAXED, false), 3);
                level.levelEvent(null, 3004, pos, 0); // wax off
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (harvest != null && maxStage > 0 && state.getValue(STAGE) >= maxStage) {
            if (!level.isClientSide) {
                Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(PmpMod.MODID, harvest));
                if (it != null) Block.popResource(level, pos, new ItemStack(it, 1 + level.random.nextInt(3)));
                level.setBlock(pos, state.setValue(STAGE, Math.max(0, maxStage / 2)), 2);
                level.playSound(null, pos, SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, SoundSource.BLOCKS, 1.0F, 0.8F + level.random.nextFloat() * 0.4F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
