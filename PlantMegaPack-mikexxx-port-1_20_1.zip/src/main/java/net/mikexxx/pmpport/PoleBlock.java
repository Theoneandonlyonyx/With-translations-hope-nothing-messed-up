package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Thin 4x4 pole that can be placed along any axis. */
public class PoleBlock extends RotatedPillarBlock {
    private static final VoxelShape Y = Block.box(6, 0, 6, 10, 16, 10);
    private static final VoxelShape X = Block.box(0, 6, 6, 16, 10, 10);
    private static final VoxelShape Z = Block.box(6, 6, 0, 10, 10, 16);

    public PoleBlock(Properties p) {
        super(p);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return switch (s.getValue(AXIS)) {
            case X -> X;
            case Z -> Z;
            default -> Y;
        };
    }
}
