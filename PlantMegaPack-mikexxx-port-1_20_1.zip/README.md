# PlantMegaPack mikexxx port (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.

Rev 3:
- Removed duplicate plants (same texture, different name): kept the specific 1.7.10 cultivar names, kept 1.12.2 colours only where 1.7.10 has none.
  Flowers are sorted by plant, then rainbow order (dark red -> red -> coral -> orange -> yellow -> green -> cyan -> blue -> royal -> purple -> magenta -> pink -> white).
- Tall plants are separate blocks: 1.12.2 3-segment plants = Bottom / Middle / Top blocks, 2-block plants = Bottom / Top blocks,
  1.7.10 plants with 6/8/10 stage textures = one block per stage (Stage 1..n). Plants with 2-5 stages still grow with bone meal.
- Epiphytes (18) are wall-mounted blocks that attach to the side of logs/blocks.

Rev 4:
- Medium / large plants are ONE block + ONE item again. 1.7.10 'DOUBLE' plants (taken from the jar's plant table): 2 single-block stages, then
  bottom/top pairs from stage 3 on (growing via bone meal / random ticks, the top is placed when it reaches a 2-block stage). 1.12.2 large plants
  (3 segments, 2 wide) and 2-segment plants use the jar's own models. Honeycomb waxes all segments, axe removes the wax.
- Stage-split entries removed: every single-block growth plant is one inventory item.
- Berry bushes: right-click when fully grown -> berries drop, the bush goes back to an earlier stage.
- Flowers tab: rainbow-order colour flowers first, then flowers with colour families kept together in rainbow order.
- All mod tabs are chained so they sit next to each other.

Rev 5:
- Medium plants (Burning Bush, Cinnamon Fern, Dwarf Pine, Japanese Pieris, Prairie Junegrass, Sheep Laurel, Slender Firethorn, Woolly Bush,
  Yellow Jasmine) are now the real 2-tall/2-wide 1.12.2 plants (one block, bottom/top).
- Tillandsia Ionantha is its own epiphyte again (separate from Sky Plant).
- Creative tabs follow the original mods: Flowers, Overworld Plants, Crops, Aquatic Plants, Trees, Food, Crafting. Their registry names start with
  0_..6_ and are chained, so they stay together and in this order.
- Colour families are sorted by number of colours (most first, rainbow order inside), the rest follows.
- Ground covers and floating plants (water lilies etc.) are flat on the ground/water with random rotation instead of crosses.
- Hanging plants are whole pieces now (1.12.2 ones use top+bottom textures, 1.7.10 ones their complete single-block texture).

## 1.3.0 changes
- Single mod again: your original source + fixes merged in (no pre-compiled `base/`, no extension mod). Build output is ONE jar.
- Hanging plants: new `HangingPlantBlock` (2 blocks; 1.12.2 vines and sweet peas 3 blocks). Attach to ceilings, leaves, chains (vanilla + modded), wall brackets, hooks.
- Water plants: new `WaterPlantBlock`
  - aquatic crops (rice, wild rice, centella, laksa leaf, watercress, water spinach): only in 1-block-deep water on soil
  - lotus / wasabi / taro: in 1-deep water OR on soil/mud next to water OR on mud
  - immersed plants: bottom block in 1-deep water, upper 1-2 blocks above the surface (grow after the last stage)
  - all grow (random tick + bone meal), honeycomb waxes, axe removes wax
- Tall crops (brussels sprout, burdock, cassava, land cress, orache, skirret, corn): stage -> frame mapping fixed.
- Creative tab "PMP: All Plants (colour filter)" + `config/pmp_mikexxx/plant_colors.json`.
- Duplicate Tillandsia ionantha removed (kept "Sky Plant").
- German translation completed (de_de.json): every key translated, swapped cultivar names fixed, "(Stufe n)" suffixes removed.
